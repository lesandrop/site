from django.apps import AppConfig


class DigestConfig(AppConfig):
    name = 'digest'
